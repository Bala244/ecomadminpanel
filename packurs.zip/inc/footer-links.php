</div>
    </div>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <!-- <script>
        $(document).on('click','a', function(e){
           e.preventDefault();
           var pageURL=$(this).attr('href');
           
            history.pushState(null, '', pageURL);
             
            $.ajax({    
               type: "GET",
               url: "/ecomadminpanel/"+pageURL+"",         
               dataType: "html",                  
               success: function(data){ 
                 
                $('body').html(data);    
                       
               }
           });
        });
    </script> -->